import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MessageHandler {
	private Map<String, ArrayList<Message>> users = new HashMap<String, ArrayList<Message>>();
	private Map<Integer, String> messages = new HashMap<Integer, String>();
	
	public int Add(String recipientID, String senderID, String message)
	{
		if (!message.isEmpty()) {
			Message newMessage = new Message(message, recipientID, senderID);
			
			if (users.containsKey(recipientID)) {
				users.get(recipientID).add(newMessage);
			}
			else {
				users.put(recipientID, new ArrayList<Message>());
				users.get(recipientID).add(newMessage);
			}
			messages.put(newMessage.MessageID, recipientID);
			return newMessage.MessageID;
		}
		
		return -1;
	}
	
	ArrayList<Message> GetUserMessages(String userID)
	{
		if (users.containsKey(userID)) {
			return users.get(userID);
		}
		return new ArrayList<Message>();
		
	}
	
	String GetUserByMessageID(int messageID)
	{
		if (messages.containsKey(messageID)) {
			return messages.get(messageID);
		}
		return null;
		
	}
	
	public int Delete(int messageID) {
		ArrayList<Message> ownerMessages = GetUserMessages(GetUserByMessageID(messageID));
		for (int i = 0; i < ownerMessages.size(); i++) {
			if (ownerMessages.get(i).MessageID == messageID) {
				messages.remove(messageID);
				users.get(ownerMessages.get(i).RecipientNumber).remove(ownerMessages.get(i));
				return messageID;
			}
			
		}
		
		
		return -1;
	}
	
	public String Fetch(String recipientID) {
		ArrayList<Message> messages = GetUserMessages(recipientID);
		
		ArrayList<Message> unFetchedMessages = new ArrayList<Message>();
		
		StringBuilder xmlOutput = new StringBuilder();
		xmlOutput.append("<List>");
		for (Message message : messages) {
			if (!message.Fetched) {
				unFetchedMessages.add(message);
				message.Fetched = true;
				xmlOutput.append(message.Serialize());
			}
		}
		xmlOutput.append("</List>");
		
		return xmlOutput.toString();
	}
	
	
	public int Replace(int messageID, String message) {
		if (message.isEmpty()) {
			return -1;
		}
		
		ArrayList<Message> ownerMessages = GetUserMessages(GetUserByMessageID(messageID));
		for (int i = 0; i < ownerMessages.size(); i++) {
			//System.out.println("Key: " + ownerMessages.get(i).MessageID + " Value: " + ownerMessages.get(i).Content );
			if (ownerMessages.get(i).MessageID == messageID && ownerMessages.get(i).Fetched == false) {		
				//Messages.put will replace the message with the new message automatically if the MessageID is entered again
				Message newMessage = ownerMessages.get(i);
				newMessage.Content = message;
				ownerMessages.set(i, newMessage);
				//System.out.println(messages.put(messageID, message).toString());
				return messageID;	
				
			}
			
		}
		//If error is encountered
		return -1;
	}
}
